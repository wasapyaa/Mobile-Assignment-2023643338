package com.example.carloan;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    EditText etVehiclePrice, etDownPayment, etLoanPeriod, etInterestRate;
    TextView tvResult;
    Button btnCalculate;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etVehiclePrice = findViewById(R.id.etVehiclePrice);
        etDownPayment = findViewById(R.id.etDownPayment);
        etLoanPeriod = findViewById(R.id.etLoanPeriod);
        etInterestRate = findViewById(R.id.etInterestRate);
        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        btnCalculate.setOnClickListener(v -> calculateLoan());

        // Bottom Navigation listener
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                Toast.makeText(MainActivity.this, "You are on Home", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.nav_about) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
            return true;
        });
    }

    private void calculateLoan() {
        try {
            double vehiclePrice = Double.parseDouble(etVehiclePrice.getText().toString());
            double downPayment = Double.parseDouble(etDownPayment.getText().toString());
            int loanPeriod = Integer.parseInt(etLoanPeriod.getText().toString());
            double interestRate = Double.parseDouble(etInterestRate.getText().toString());

            double loanAmount = vehiclePrice - downPayment;
            double totalInterest = loanAmount * (interestRate / 100) * loanPeriod;
            double totalPayment = loanAmount + totalInterest;
            double monthlyPayment = totalPayment / (loanPeriod * 12);

            String result = "Loan Amount: RM" + String.format("%.2f", loanAmount) + "\n" +
                    "Total Interest: RM" + String.format("%.2f", totalInterest) + "\n" +
                    "Total Payment: RM" + String.format("%.2f", totalPayment) + "\n" +
                    "Monthly Payment: RM" + String.format("%.2f", monthlyPayment);

            tvResult.setText(result);

        } catch (Exception e) {
            Toast.makeText(this, "Please fill all fields correctly", Toast.LENGTH_SHORT).show();
        }
    }
}